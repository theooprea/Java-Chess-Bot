public class Queen extends Piece {
    public Queen(int color, int row, int column) {
        super(Piece.Queen, color, row, column);
    }

    @Override
    public boolean move() {
        return false;
    }
}
