import java.util.ArrayList;

public class Board {
    public Piece[][] matrix; // board state matrix
    public static Board instance = null;
    public ArrayList<Piece> piecesBlack;
    public ArrayList<Piece> piecesWhite;

    // The 2 pawns moved at stage 1 of the project.
    public Pawn stage_one_black_pawn;
    public Pawn stage_one_white_pawn;

    // create board
    private Board() {
        matrix = new Piece[8][8];
        piecesBlack = new ArrayList<>();
        piecesWhite = new ArrayList<>();

        initialize();
    }

    public void initialize() {
        // Pawns
        for (int i = 0; i < 8; i++) {
            Pawn p1 = new Pawn(Piece.White,1, i);
            Pawn p2 = new Pawn(Piece.Black, 6, i);
            piecesWhite.add(p1);
            piecesBlack.add(p2);
            matrix[1][i] = p1;
            matrix[6][i] = p2;
        }
        stage_one_black_pawn = (Pawn)piecesBlack.get(3);
        stage_one_white_pawn = (Pawn)piecesWhite.get(3);

        // Kings and Queens
        King k1 = new King(Piece.White, 0, 4);
        King k2 = new King(Piece.Black, 7, 4);
        Queen q1 = new Queen(Piece.White, 0, 3);
        Queen q2 = new Queen(Piece.Black, 7, 3);
        piecesBlack.add(k2);
        piecesBlack.add(q2);
        piecesWhite.add(k1);
        piecesWhite.add(q1);
        matrix[0][4] = k1;
        matrix[7][4] = k2;
        matrix[0][3] = q1;
        matrix[7][3] = q2;

        // Knights
        Knight c1 = new Knight(Piece.White, 0, 1);
        Knight c2 = new Knight(Piece.White, 0, 6);
        Knight c3 = new Knight(Piece.Black, 7, 1);
        Knight c4 = new Knight(Piece.Black, 7, 6);
        piecesBlack.add(c3);
        piecesBlack.add(c4);
        piecesWhite.add(c1);
        piecesWhite.add(c2);
        matrix[0][1] = c1;
        matrix[0][6] = c2;
        matrix[7][1] = c3;
        matrix[7][6] = c4;

        // Bishops
        Bishop b1 = new Bishop(Piece.White,0,2);
        Bishop b2 = new Bishop(Piece.White,0,5);
        Bishop b3 = new Bishop(Piece.Black,7,2);
        Bishop b4 = new Bishop(Piece.Black,7,5);
        piecesBlack.add(b3);
        piecesBlack.add(b4);
        piecesWhite.add(b1);
        piecesWhite.add(b2);
        matrix[0][2] = b1;
        matrix[0][5] = b2;
        matrix[7][2] = b3;
        matrix[7][5] = b4;

        // Rooks
        Rook r1 = new Rook(Piece.White,0,0);
        Rook r2 = new Rook(Piece.White,0,7);
        Rook r3 = new Rook(Piece.Black,7,0);
        Rook r4 = new Rook(Piece.Black,7,7);
        piecesBlack.add(r3);
        piecesBlack.add(r4);
        piecesWhite.add(r1);
        piecesWhite.add(r2);
        matrix[0][0] = r1;
        matrix[0][7] = r2;
        matrix[7][0] = r3;
        matrix[7][7] = r4;
    }

    public ArrayList<Pawn> getBlackPawns() {
        ArrayList<Pawn> blackPawns = new ArrayList<>();
        for (Piece piece : piecesBlack) {
            if (piece.type == Piece.Pawn) {
                blackPawns.add((Pawn) piece);
            }
        }
        return blackPawns;
    }

    public ArrayList<Pawn> getWhitePawns() {
        ArrayList<Pawn> whitePawns = new ArrayList<>();
        for (Piece piece : piecesWhite) {
            if (piece.type == Piece.Pawn) {
                whitePawns.add((Pawn) piece);
            }
        }
        return whitePawns;
    }

    public static Board getInstance() {
        if (instance == null) {
            instance = new Board();
        }
        return instance;
    }

    public void reinitialize() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                matrix[i][j] = null;
            }
        }
        piecesBlack.clear();
        piecesWhite.clear();

        initialize();
    }

    // Function that updates the internal representation of the board.
    public void update(char initial_column, char initial_row, char final_column, char final_row) {
        Piece toMove = matrix[initial_row - '1'][initial_column - 'a'];
        Piece whereToMove = matrix[final_row - '1'][final_column - 'a'];
        boolean resign = false;

        toMove.row = final_row - '1';
        toMove.column = final_column - 'a';

        // Check if we need to remove pieces at this move.
        if (whereToMove != null) {
            if (whereToMove.color == Piece.Black) {
                piecesBlack.remove(whereToMove);
            }
            else {
                piecesWhite.remove(whereToMove);
            }
        }

        // Check if we need to add a queen at this move.
        if (toMove.color == Piece.Black && toMove.row == 0 && toMove.type == Piece.Pawn) {
            piecesBlack.remove(toMove);
            toMove = new Queen(Piece.Black, toMove.row, toMove.column);
            piecesBlack.add(toMove);
            resign = true;
        }
        if (toMove.color == Piece.White && toMove.row == 7 && toMove.type == Piece.Pawn) {
            piecesWhite.remove(toMove);
            toMove = new Queen(Piece.White, toMove.row, toMove.column);
            piecesWhite.add(toMove);
            resign = true;
        }

        matrix[initial_row - '1'][initial_column - 'a'] = null;
        matrix[final_row - '1'][final_column - 'a'] = toMove;

        if (resign) {
            System.out.println("resign");
        }
    }

    /*
    Function that sends the actual move command to the xboard and updates the
    internal representation of the board.
     */
    public void move(char initial_column, char initial_row, char final_column, char final_row) {
        System.out.println("move " + initial_column + initial_row + final_column + final_row);
        update(initial_column, initial_row, final_column, final_row);
    }

    /*
    Function that checks if we can make a new valid move at this moment.
     */
    public void nextMove (int color) {
        if (color == Piece.Black) {
            if (piecesBlack.contains(stage_one_black_pawn)) {
                if (!stage_one_black_pawn.move()) {
                    System.out.println("resign");
                }
            }
            else {
                System.out.println("resign");
            }
        }
        else {
            if (piecesWhite.contains(stage_one_white_pawn)) {
                if (!stage_one_white_pawn.move()) {
                    System.out.println("resign");
                }
            }
            else {
                System.out.println("resign");
            }
        }
    }

    /*
    Function that prints the internal representation of the board (for debugging).
     */
    public void print() {
        for (int i = 7; i >= 0; i--) {
            for (int j = 0; j < 8; j++) {
                Piece piece = matrix[i][j];
                if (piece == null) {
                    System.out.print("_ ");
                }
                else {
                    if (piece.color == Piece.Black) {
                        if (piece.type == Piece.Pawn) {
                            System.out.print("P ");
                        }
                        else if (piece.type == Piece.King) {
                            System.out.print("K ");
                        }
                        else if (piece.type == Piece.Queen) {
                            System.out.print("Q ");
                        }
                        else if (piece.type == Piece.Knight) {
                            System.out.print("C ");
                        }
                        else if (piece.type == Piece.Bishop) {
                            System.out.print("B ");
                        }
                        else {
                            System.out.print("R ");
                        }
                    }
                    else {
                        if (piece.type == Piece.Pawn) {
                            System.out.print("p ");
                        }
                        else if (piece.type == Piece.King) {
                            System.out.print("k ");
                        }
                        else if (piece.type == Piece.Queen) {
                            System.out.print("q ");
                        }
                        else if (piece.type == Piece.Knight) {
                            System.out.print("c ");
                        }
                        else if (piece.type == Piece.Bishop) {
                            System.out.print("b ");
                        }
                        else {
                            System.out.print("r ");
                        }
                    }
                }
            }
            System.out.println();
        }
        System.out.println("Black pieces:");
        for (Piece piece : piecesBlack) {
            if (piece.type == Piece.Pawn) {
                System.out.print("P ");
            }
            else if (piece.type == Piece.King) {
                System.out.print("K ");
            }
            else if (piece.type == Piece.Queen) {
                System.out.print("Q ");
            }
            else if (piece.type == Piece.Knight) {
                System.out.print("C ");
            }
            else if (piece.type == Piece.Bishop) {
                System.out.print("B ");
            }
            else {
                System.out.print("R ");
            }
        }
        System.out.println();
        System.out.println("White pieces:");
        for (Piece piece : piecesWhite) {
            if (piece.type == Piece.Pawn) {
                System.out.print("p ");
            }
            else if (piece.type == Piece.King) {
                System.out.print("k ");
            }
            else if (piece.type == Piece.Queen) {
                System.out.print("q ");
            }
            else if (piece.type == Piece.Knight) {
                System.out.print("c ");
            }
            else if (piece.type == Piece.Bishop) {
                System.out.print("b ");
            }
            else {
                System.out.print("r ");
            }
        }
    }
}
