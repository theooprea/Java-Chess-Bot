public class Knight extends Piece {
    public Knight(int color, int row, int column) {
        super(Piece.Knight, color, row, column);
    }

    @Override
    public boolean move() {
        return false;
    }
}
