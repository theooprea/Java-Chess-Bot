public class King extends Piece {
    public King(int color, int row, int column) {
        super(Piece.King, color, row, column);
    }

    @Override
    public boolean move() {
        return false;
    }
}
