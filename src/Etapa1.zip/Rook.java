public class Rook extends Piece {
    public Rook(int color, int row, int column) {
        super(Piece.Rook, color, row, column);
    }

    @Override
    public boolean move() {
        return false;
    }
}
