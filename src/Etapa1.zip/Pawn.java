public class Pawn extends Piece {
    public Pawn(int color, int row, int column) {
        super(Piece.Pawn, color, row, column);
    }

    @Override
    public boolean move() {
        Board board = Board.getInstance();

        // Black Pawns
        if (color == Piece.Black) {
            // Check if we can "take" an opponent piece.
            if (column == 0) {
                if (board.matrix[row - 1][1].color == Piece.White) {
                    board.move('a', (char) ('1' + row), 'b', (char) ('0' + row));
                    return true;
                }
            }
            else if (column == 7) {
                if (board.matrix[row - 1][6].color == Piece.White) {
                    board.move('h', (char) ('1' + row), 'g', (char) ('0' + row));
                    return true;
                }
            }
            else {
                if (board.matrix[row - 1][column - 1] != null && board.matrix[row - 1][column - 1].color == Piece.White) {
                    board.move((char)('a' + column), (char)('1' + row), (char)('a' + column - 1), (char)('0' + row));
                    return true;
                }
                if (board.matrix[row - 1][column + 1] != null && board.matrix[row - 1][column + 1].color == Piece.White) {
                    board.move((char)('a' + column), (char)('1' + row), (char)('a' + column + 1), (char)('0' + row));
                    return true;
                }
            }
            // If we can't take any pieces, we try to advance with 1 or two positions.
            if (row == 6) {
                if (board.matrix[5][column] == null) {
                    if (board.matrix[4][column] == null) {
                        board.move((char)('a' + column), '7', (char)('a' + column), '5');
                        return true;
                    }
                    else {
                        board.move((char)('a' + column), '7', (char)('a' + column), '6');
                        return true;
                    }
                }
                return false;
            }
            if (board.matrix[row - 1][column] == null) {
                board.move((char)('a' + column), (char)('1' + row), (char)('a' + column), (char)('0' + row));
                return true;
            }
            else {
                return false;
            }
        }
        // White Pawns
        else {
            // Check if we can take an opponent piece.
            if (column == 0) {
                if (board.matrix[row + 1][1].color == Piece.Black) {
                    board.move('a', (char) ('1' + row), 'b', (char) ('2' + row));
                    return true;
                }
            }
            else if (column == 7) {
                if (board.matrix[row + 1][6].color == Piece.Black) {
                    board.move('h', (char)('1' + row), 'g', (char)('2' + row));
                    return true;
                }
            }
            else {
                if (board.matrix[row + 1][column - 1] != null && board.matrix[row + 1][column - 1].color == Piece.Black) {
                    board.move((char)('a' + column), (char)('1' + row), (char)('a' + column - 1), (char)('2' + row));
                    return true;
                }
                if (board.matrix[row + 1][column + 1] != null && board.matrix[row + 1][column + 1].color == Piece.Black) {
                    board.move((char)('a' + column), (char)('1' + row), (char)('a' + column + 1), (char)('2' + row));
                    return true;
                }
            }
            // If we can't take any pieces, we try to advance with 1 or two positions.
            if (row == 1) {
                if (board.matrix[2][column] == null) {
                    if (board.matrix[3][column] == null) {
                        board.move((char)('a' + column), '2', (char)('a' + column), '4');
                        return true;
                    }
                    else {
                        board.move((char)('a' + column), '2', (char)('a' + column), '3');
                        return true;
                    }
                }
                return false;
            }
            if (board.matrix[row + 1][column] == null) {
                board.move((char)('a' + column), (char)('1' + row), (char)('a' + column), (char)('2' + row));
                return true;
            }
            else {
                return false;
            }
        }
    }
}
