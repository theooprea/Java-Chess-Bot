public class Bishop extends Piece {
    public Bishop(int color, int row, int column) {
        super(Piece.Bishop, color, row, column);
    }

    @Override
    public boolean move() {
        return false;
    }
}
