public class Evaluation {
	float profit;
	String move;

	Evaluation() {

	}

	Evaluation(float profit, String move) {
		this.profit = profit;
		this.move = move;
	}
}
